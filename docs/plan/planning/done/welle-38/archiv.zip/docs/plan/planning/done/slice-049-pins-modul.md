# Slice slice-049: Modul `pins` — Content-Pin gegen inhaltlichen Drift (Idee 2)

**Status:** done (abgeschlossen, welle-38-pins).

**Welle:** welle-38-pins (Trigger: Auftraggeber-Idee — „wenn man einen
Markdown-Link auf eine Datei/Absatz setzt, könnte d-check den Drift bemerken";
nach Spike bestätigt).

**Bezug:** Idee 2 dieser Session-Kette. Führt eine **neue PIN-Anforderung** im
Lastenheft ein (Modul `pins`, Content-Pin/`link-stale`) plus einen
**begleitenden ADR** (Fence-Öffnung für den Ziel-Span, Mechanik-Präzedenz
[ADR-0018](../../adr/0018-diagram-fence-ausnahme.md)). Verteilung wie der Rest
des Werkzeugs (gepinntes Image, kein kopiertes Skript —
[`MR-007`](../../../../harness/conventions.md#mr-007--auflösung-von-mr-003-doc-check-als-dogfooding)-Linie).

**Autor:** pt9912. **Datum:** 2026-06-24.

---

## 1. Ziel

Strukturellen Drift fängt d-check schon: Ziel-Datei/-Anker weg →
`target-missing`/`anchor-missing`. **Neu:** *inhaltlicher* Drift — der Link löst
weiter auf, aber der **Inhalt** des Ziel-Spans hat sich seit dem Verlinken
geändert; die zitierende Aussage daneben ist evtl. veraltet (das klassische
„stale citation"-Problem). Ein optionaler **Content-Pin** (Hash des Ziel-Spans
zum Verlink-Zeitpunkt) macht das entscheidbar: d-check re-hasht den aufgelösten
Span und vergleicht; Mismatch → Befund `link-stale`. Gleiche Disziplin wie der
Image-Digest-Pin (pinnen → bei Änderung neu segnen), auf Doku-Querverweise
angewandt.

## 2. Entscheidungen

- **Entscheidbar statt semantisch.** Hash-Vergleich ist deterministisch + offline
  ([`DC-QA-02`](../../../../spec/lastenheft.md#dc-qa-02--determinismus)/[`DC-QA-03`](../../../../spec/lastenheft.md#dc-qa-03--seiteneffektfreiheit-und-netzwerk-sparsamkeit));
  „ist das Zitat *sinngemäß* noch richtig?" wäre nicht gatebar und bleibt
  Out-of-Scope. Dieselbe Linie wie [ADR-0018](../../adr/0018-diagram-fence-ausnahme.md)
  (Existenz/Referenz, nicht Grammatik).
- **Ziel-Span:** ganze Datei (Link ohne Anker) oder Heading-Section (Anker → bis
  zur nächsten gleich-/höherrangigen Überschrift; Section-Logik aus
  `matrix`/`anchors` wiederverwendbar). Absatz-Ebene ist in Markdown nicht stabil
  adressierbar → draußen.
- **Roher Span inkl. Fenced-Code hashen** (Drift in Code-Beispielen ist ein
  Zielfall) — bewusste, eng begrenzte Ausnahme von der Fence-Opazität; Präzedenz
  [ADR-0018](../../adr/0018-diagram-fence-ausnahme.md) → eigener ADR.
- **Normalisierung whitespace-/reflow-invariant** (Wort-Inhalt, nicht
  Byte-Layout) — Spike 2026-06-24: 0/87 kosmetische Trips, das Rauschen
  materialisiert sich nur ohne Normalisierung.
- **opt-in pro Link:** nur Links **mit** Pin werden geprüft (der Pin ist die
  bewusste „hier zitiere ich Inhalt"-Markierung); strikt opt-in Modul, default-off
  byte-identisch.
- **diagnose-only v1:** `link-stale` liefert keinen `--repair`-Hunk — Re-Pinnen
  ist menschliche Annahme der Drift, kein eindeutig ableitbarer Fix; ein
  explizites `--bless` ist eine spätere CR.
- **Pin-Ablage inline:** `<!-- dpin: sha256:<hash> -->` direkt nach dem Link
  (lokal, git-diff-freundlich) — dieselbe Mechanik wie der `d-check:ignore`-Marker.
- **Eigenes Modul `pins`** (nicht mit `versions` verschmolzen): andere Mechanik
  (Span-Hash vs. Wert-Gleichheit), je einzeln opt-in und testbar.

## 3. Definition of Done

- [x] **Spec:** neue PIN-Anforderung im Lastenheft (neues Bereichskürzel `PIN` in
  §3, Versions-Bump + §7-Historie) + begleitender ADR (Fence-Öffnung) +
  spezifikation `.a`-Sektion + Grund-Code `link-stale` (§4) + `pins` als gültiges
  Modul in [`DC-FA-CLI-002`](../../../../spec/lastenheft.md#dc-fa-cli-002--regelmodul-auswahl)/Glossar
  + ADR-Index; doc-first vor Code. Die `.a` legt **deterministisch** fest (R1):
  (a) **Marker-Bindung** — der Pin bindet an den unmittelbar (nur Whitespace)
  vorausgehenden Link derselben Zeile; nicht eindeutig zuordenbare Marker sind
  inert; (b) **nicht auflösbares Ziel** — `pins` wertet nur auflösbare Links, der
  strukturelle Befund bleibt bei `links`/`anchors` (kein eigener `pins`-Befund,
  auch im pins-only-Lauf); (c) `pins` respektiert den Modul-Scope
  ([`DC-FA-CONF-002`](../../../../spec/lastenheft.md#dc-fa-conf-002--modul-lokaler-scan-scope)).
- [x] **Code:** Modul `pins` (Marker-Erkennung mit deterministischer Bindung,
  Ziel-Span-Auflösung, whitespace-Normalisierung, Hash + Vergleich, `link-stale`).
  Tests: Happy/Reflow-Boundary/Negative/Modul-aus; **Marker-Ambiguität** (zwei
  Links/Zeile, Marker zwischen Links, Marker auf Folgezeile); **Ziel-weg**
  (pins-only → kein `link-stale`; mit `links` aktiv → `target-missing`, kein
  Doppelbefund); **`pins.scope`** — Befunde nur im effektiven Modul-Scope.
- [ ] `make gates` grün; unabhängiges Review; Closure (Move nach `done/` +
  Roadmap-Flip, [`MR-013`](../../../../harness/conventions.md#mr-013--lifecycle-move-commit-bündelt-gekoppelte-verweise)).

## 4. Risiken / offene Punkte

- **Normalisierung ist ein Vertrag** (definiert, was „inhaltliche Änderung"
  heißt) — Spike-kalibriert, exakt zu dokumentieren; konservativ.
- **Pin-Erstellung/-Erneuerung** ist menschlich (read-only-Kernvertrag); ein
  `--bless`-Emissionsmodus berührt den Reparatur-Vertrag und ist spätere CR.
- **Fence-Öffnung breiter begründen** als bei `diagrams` (ganzer Span statt
  gelistete Diagramm-Fences) — gehört in den ADR; opt-in default-off hält die
  Abwärtskompatibilität.

## 5. Trigger

Auftraggeber: „Idee 2 als Slice angehen" (2026-06-24), nach Spike + Design-
Diskussion; Reihenfolge D nach Idee 1 (slice-048 done, Release v0.28.0).

## 6. Sub-Area-Modus-Begründung

GF (Produkt-Code + Spec; „Doc führt, Code folgt"). Keine BF-Sub-Area.

## 7. Closure-Notiz (nach `done/`)

**Umsetzung.** Idee 2 als 11. Regelmodul `pins`: ein Link mit Content-Pin
`<!-- dpin: sha256:… -->` (gebunden an den unmittelbar — nur Whitespace, geprüft
auf der **rohen** Zeile — vorausgehenden Nicht-Bild-Link) wird gegen den
whitespace-normalisierten **rohen** Ziel-Span (ganze Datei oder Heading-Section,
inkl. Fenced-Code) gehasst; Drift → `link-stale`. Nur auflösbare, repo-interne
Ziele (struktureller Befund bleibt `links`/`anchors`, kein Doppelbefund, auch
pins-only); Scope-treu
([`DC-FA-CONF-002`](../../../../spec/lastenheft.md#dc-fa-conf-002--modul-lokaler-scan-scope)),
diagnose-only. Doc-first:
[`DC-FA-PIN-001`](../../../../spec/lastenheft.md#dc-fa-pin-001--content-pin-gegen-inhaltlichen-drift-modul-pins-opt-in)
(Lastenheft 0.29.0, Bereich `PIN`) +
[ADR-0020](../../adr/0020-content-pin-fence-ausnahme.md) + spezifikation `.a`/
Grund-Code `link-stale` gingen dem Code voraus.

**Belege.**
- `make gates` **grün** (doc-check, lint, test, arch-check, Coverage 94,00 %,
  semgrep, gate-consistency, planning-check); `make ci` grün (image-test).
- Plan-Review **R1→R2→R3** (4→3→2 Befunde, alle behoben) + **unabhängiges
  Impl-Review** (2 MEDIUM/1 LOW/1 INFO behoben: Marker-Bindung auf roher Zeile,
  Negativtests, Bild-Link-/Leeranker-Spec).
- 12 Tests (`rules/pins_test.go`); `CheckPins`/`bindPins`/`pinFinding` 100 % Coverage.
- **Kein `.d-check.yml`-Dogfooding:** das Repo hat (noch) keine gepinnten Links —
  die Querverweise sind Navigation (`ids`-Sache), der reale Drift war Versions-/
  Datums-Art (`versions`-Sache). `pins` ist ausgeliefert/opt-in; Adoption, wenn ein
  echtes Inhalts-Zitat auftaucht (Auftraggeber-Entscheid 2026-06-24).
- Release **v0.29.0** auf GHCR (Run `28102716631` grün, Tags `v0.29.0`+`latest`),
  Digest-Pin
  `ghcr.io/pt9912/d-check@sha256:07994926987a92b863a5f54eeb7668654c08e1be958be425da4bdb7712c002c2`.

**Lerneintrag.** `pins` und `versions` (slice-048) sind dieselbe Disziplin (pinnen
→ bei Änderung neu segnen, wie der Image-Digest-Pin), aber getrennte Module:
`versions` = Wert-Gleichheit gegen eine deklarierte aktuelle Version, `pins` =
Span-Hash gegen einen hinterlegten Pin. Die Marker-Bindung muss auf der **rohen**
Zeile geprüft werden (die Vorverarbeitung leert Inline-Code zu Leerzeichen —
Impl-R1 F-1).

# Slice slice-282: Anforderung, Spezifikation und ADR für das Modul `metrics`; Bestands-Gegenprobe

**Lifecycle:** Der Zustand dieses Slice ist das Verzeichnis, in dem diese
Datei liegt — eines von `open/`, `next/`, `in-progress/`, `done/`. Er
wechselt nur durch `git mv`, siehe
Baseline-Regelwerk `modul-05-planning-harness.md` §Lifecycle als State Machine.
Übernimmt ein anderer Slice den Gegenstand oder entfällt er, geht diese Datei
aus `open/` oder `next/` nach `done/` — §7 nennt in der Zeile `Gegenstand:`
Kennung oder Grund, die Liefer-Punkte der DoD bleiben leer
(§Ein Slice, dessen Gegenstand ein anderer übernimmt).

**Welle:** welle-93

**Bezug:** [`DC-QA-02`](../../../../../spec/lastenheft.md#dc-qa-02--determinismus) (Determinismus der Formel und der Messung),
[`DC-QA-03`](../../../../../spec/lastenheft.md#dc-qa-03--seiteneffektfreiheit-und-netzwerk-sparsamkeit) (kein Schreiben, kein Netz). Die Anforderung des Moduls
entsteht in diesem Slice und trägt erst danach eine Kennung; Vorbild für Form und
Reihenfolge sind [`DC-FA-MENT-001`](../../../../../spec/lastenheft.md#dc-fa-ment-001--erwähnungs-deckung-einer-artefakt-menge-modul-mentions-opt-in) und
[`DC-FA-VCS-001`](../../../../../spec/lastenheft.md#dc-fa-vcs-001--git-diff-immutabilität-des-core-über-eine-commit-range-modul-vcs-opt-in). Eine begleitende ADR hält die Entscheide fest (Nummer bei der Anlage).

**Berührte Spec-Stellen:** `spec/lastenheft.md` (neue Anforderung, §3
Bereichskürzel-Liste, Historie) · `spec/spezifikation.md §2` (Schema
`metrics.*`) und §7 (Grund-Codes) · `spec/architecture.md` ([`ARC-005`](../../../../../spec/architecture.md),
[`ARC-010`](../../../../../spec/architecture.md) und die Fehlerzeile zum Adapter) — die Kennungen entstehen mit dem Slice.
Der Verweis zeigt **aufwärts**: Die Spec nennt diesen Slice nie
(Baseline-Regelwerk `grundlagen-referenz-richtung.md`
§Referenz-Richtung (SDP), `grundlagen-source-precedence.md` §ID-Schema als Klammer).

**Verantwortlich:** pt9912

**Autor:** pt9912. **Datum:** 2026-10-30.

---

## 1. Ziel und Abgrenzung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — Schnitt nach Lieferwert, nicht nach Schichten; jeder Slice
ist einzeln lieferbar. **§1 nennt Ziel und Abgrenzung** (Out-of-Scope-Disziplin
des Lastenhefts, auf den Slice-Plan angewandt); die vier Klassen des
Ausschlusses stehen in **eben diesem Abschnitt** des Baseline-Regelwerks,
zusammen mit der Begründungs-Pflicht je Punkt.

**Ziel:** Die Anforderung des Moduls `metrics` steht im Lastenheft, ihre
Schnittstelle in der Spezifikation und ihre Entscheide in einer ADR — **bevor**
Code entsteht, und gegen die anonymisierten Angaben des Anlass-Repos gemessen
(Issue-Kommentar vom 2026-10-30: Block, Formel, Zustände, Messung), statt aus dem
Issue geraten. Das Repo selbst ist nicht lesbar.

**Die neun Entscheide, die das Issue offenlässt** und die dieser Slice setzt (mit
Empfehlung; die Entscheide trifft der Auftraggeber, vor dem Schreiben der
Anforderung). Die Empfehlungen folgen den Angaben des Anlass-Repos:

1. **Syntax des Blocks im Plan und Plan-Suche.** Ein Fenced-Block (Backticks oder
   Tilden, genau einer je Plan), dessen Info-String der konfigurierte Blockname ist,
   mit **Zeilen-Syntax** `<schluessel>: <wert>`, getrennt am ersten `:`, beide Seiten
   getrimmt; Schlüssel für Pfade und Ausnahmen dürfen mehrfach stehen, alle anderen
   höchstens einmal; keine Verschachtelung, keine Listen — **kein YAML** (siehe
   Entscheid 6). Zahlen: ASCII-Ziffern, keine führende Null. Schlüssel- und Feldnamen
   sind Konfiguration (Issue: „Blockname … Feldnamen“). Geprüft wird jede Datei
   `slice-*.md` **unmittelbar** im konfigurierten Plan-Verzeichnis (nicht rekursiv,
   nach Namen sortiert); ohne Datei ist der Lauf grün.
2. **Woher die Basis `<basis>` kommt.** Ein Feld des Blocks (7 bis 40 Zeichen
   `0-9a-f`), `HEAD` ist fest. Nicht `--range` auf der Kommandozeile: ein Lauf prüft
   mehrere Pläne mit je eigener Basis. Eine Basis, die nicht auflöst oder kein
   Vorfahr von `HEAD` ist, ist ein Eingabefehler (Exit 2).
3. **Form der Formel.** **Ganzzahlig** ([`DC-QA-02`](../../../../../spec/lastenheft.md#dc-qa-02--determinismus), kein Gleitkomma, kein
   Ausdrucks-Parser), zwei Stufen. Schätzung: `S = Σ Klassenfaktor · Zeilen der Klasse
   + Σ Feldfaktor · Feld` (Zeilen aus der Tabelle des Plans, Entscheid 9; Felder des
   Blocks). Obergrenze: `Einheit · ⌈Zähler · S / Nenner⌉` (genau eine Aufrundung auf ein
   Vielfaches der Einheit). Prüfung 1 rechnet die Obergrenze aus dem Block-Feld
   `schaetzung`, Prüfung 2 hält dieses Feld gegen die berechnete Schätzung. Dazu eine
   **Schwellenregel**: ab einer konfigurierten Schwelle für `Zähler · S` ist ein weiteres
   Feld Pflicht. Die Werte (im Anlass-Repo 85/80 je Klasse, 200 für `fakes`, 1 für
   `produktcode`, 135/10000, Einheit 100, Schwelle 300000) sind Konfiguration, nicht
   Code. Die Formel ändert sich nie mit einem Zustand. Felder des Blocks, die die
   Konfiguration nicht nennt, werden ignoriert.
4. **Was `git diff --numstat` hier heißt.** Einfügungen plus Löschungen je Datei,
   **Rename-Erkennung aus** (wie `--no-renames`: Löschung plus Einfügung); Pfade als
   **literale** Pathspecs (keine Glob-Muster, ein Verzeichnis zählt rekursiv, ein Pfad
   ohne Änderung trägt 0 bei, ein Pfad, der weder an der Basis noch an HEAD existiert, gibt einen Hinweis, dieselbe Datei über zwei Pfade zählt einmal);
   Binärdateien (`-` in `numstat`) zählen 0 mit Hinweis; ein konfigurierter Teilbaum
   ist immer ausgenommen; nicht eingecheckte Änderungen zählt die Messung nicht. Die
   Messung läuft über den VCS-Port ohne git-Binary — die Gleichheit mit dem Kommando
   ist eine **Behauptung, die [`slice-284`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) am Fixture belegt**, nicht dieser Slice.
5. **Befunde, Eingabefehler, Hinweise und der Ausnahme-Eintrag.** Ein **Eingabefehler**
   eines Plans (Block unvollständig, Zahl ungültig, Fence ungeschlossen, Basis
   unauflösbar) ist Exit 2 mit Klartext; der Lauf bricht beim ersten Fehler ab, kein Befund erscheint —
   kein Befund-Code, damit `metrics-block-invalid` entfällt. **Befunde:**
   `metrics-limit-mismatch`, `metrics-estimate-mismatch`, `metrics-over-limit`, `metrics-reason-empty`,
   `metrics-cut-reason-missing` (Schwellenregel ohne Pflichtfeld). **Hinweise** (keine
   Befunde): Plan ohne Block, Binärdateien nicht gezählt, Ausnahme-Eintrag ohne
   Überschreitung. Ausnahme-Eintrag `<N> | <Grund>`: deckt eine Messung bis `N`
   (`N` ≥ Messung); ein leerer Grund ist selbst ein Befund, auch wenn er deckt; bei
   Messung im Rahmen ist der Eintrag nur ein Hinweis. Ein Protokoll-Eintrag über
   frühere Marken wird nicht geprüft.
6. **Wo der Block gelesen wird.** Der Kern trägt keine YAML-Bibliothek
   ([`ARC-002`](../../../../../spec/architecture.md), Verbotsspalte; `yaml.v3` ist in `.a-check.yml` auf die Adapter
   `configyaml`, `report`, `workflowyaml` beschränkt). Die Zeilen-Syntax aus
   Entscheid 1 braucht keinen: (a) **Zeilen-Syntax im Kern** (Empfehlung — kein neuer
   Port, drei Slices bleiben); (b) ein Parse-Port nach dem Muster von `WorkflowParser`
   ([`ADR-0072`](../../../adr/0072-workflows-modul.md)) wäre nur nötig, wenn die Syntax
   YAML verlangte — nach den Angaben des Anlass-Repos nicht.
7. **Fence-Behandlung.** Keine eigene Ausnahme neben der geteilten Vorverarbeitung: das Modul
   liest die Plan-Dateien selbst und erkennt Zäune mit dem Öffner-Test des Produkts,
   längengleich geschlossen (wie der Tabellen-Leser der RTM). Ein **ungeschlossener**
   Fence ist ein Eingabefehler (Entscheid 5), nicht still „ohne Block“.
8. **Wo die Zeilen gezählt werden.** Empfehlung: neue Methode am VCS-Port (der
   Adapter besitzt den Diff; Parameter: Basis, Pfade, ausgenommener Teilbaum). Die
   Alternative — der Kern zählt selbst über `AllPaths` und `FileAt` — braucht keinen
   Port-Zuwachs, aber einen Zeilen-Diff im Kern; die
   ADR verwirft eine der beiden mit Begründung, und `spec/architecture.md`
   ([`ARC-005`](../../../../../spec/architecture.md), [`ARC-010`](../../../../../spec/architecture.md), Fehlerzeile) wird in diesem Slice entsprechend geschärft.
9. **Eingabe aus einer Tabelle des Plans.** Die Eingaben der Schätzung zählt das Modul
   aus **genau einer** Markdown-Tabelle des Plans außerhalb umzäunter Blöcke:
   konfigurierbarer Kopf (Zellen bytegleich), Schlüsselspalte (eindeutig, nicht leer),
   Klassenspalte mit konfigurierten Klassen samt Faktor; gezählt werden Zeilen je Klasse.
   **Gesetzt: im Modul** (Issue-Autor, Kommentar vom 2026-10-30, 14:49) — samt Prüfung 2
   „Schätzung gleich Tabelle“ (nur solange die Messung 0 ist, danach Hinweis) und dem
   Hinweis „Marke ausstehend“ mit berechneter Schätzung und Marke. Tabellenfehler sind
   Eingabefehler (Exit 2): Tabelle fehlt, mehrdeutig, Trennzeile fehlt, Zeile mit falscher
   Zellenzahl, `Nr.` leer oder doppelt, Klasse unbekannt, Tabelle ohne Zeilen. Es gibt
   keine Arbeitsteilung mit dem Programm des Anlass-Repos; es entfällt nach der
   Abnahme. Schnitt: [`slice-285`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle), nach der Messung, weil Prüfung 2 sie braucht.

**Die Frage aus [`AGENTS.md`](../../../../../AGENTS.md) §3.8 wird in der Anforderung beantwortet, nicht erst im Code:**
das Modul liest Eingaben, die es nie scannt — die Pfade des Blocks (außerhalb
der Scan-Wurzeln, nicht Markdown) und die git-Revisionen. Dort gilt die Zusage
der Scan-Menge nicht; die Grenze gehört in die Anforderung (wie bei
[`DC-FA-MENT-001`](../../../../../spec/lastenheft.md#dc-fa-ment-001--erwähnungs-deckung-einer-artefakt-menge-modul-mentions-opt-in): „liest zwei Eingaben, scannt nur eine“).

**Ausdrücklich NICHT in diesem Slice** — je Punkt mit Begründung:

- **Code, Konfigurations-Leser, Gerüst, Spiegel der Modul-Registrierung** — Schicht-
  Abgrenzung: dieser Slice ist Spec und ADR, „kein Produkt-Code“ ist die wirksamste
  Selbstbindung ([`slice-283`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) trägt die Registrierung).
- **Der Modulsatz in [`DC-FA-CLI-002`](../../../../../spec/lastenheft.md#dc-fa-cli-002--regelmodul-auswahl) und die Glossar-Zeile „Regelmodul“** — der
  Spiegel-Test (`registry_mirror_test.go`) hält diese Orte in **beide** Richtungen
  gegen `model.ValidModules()`; stünde `metrics` hier schon drin, wäre `make gates`
  ab diesem Slice rot. Beide Stellen schreibt
  [`slice-283`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) mit der Registrierung.
- **Der VCS-Port, die Messung und die Prüfung gegen die Obergrenze** —
  [`slice-284`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) übernimmt sie; die Anforderung beschreibt sie hier schon vollständig,
  damit der Kern nicht ohne die Messung entworfen wird.
- **Die Antwort an das Issue und die Release-Prep** — ein anderer Vorgang
  ([`AGENTS.md`](../../../../../AGENTS.md) §5 Zeile 17), außerdem Handlung des Auftraggebers.
- **Weitere Messgrößen und schreibende Wege** — eine neue Anforderung bzw. durch
  [`DC-QA-03`](../../../../../spec/lastenheft.md#dc-qa-03--seiteneffektfreiheit-und-netzwerk-sparsamkeit) ausgeschlossen; die Out-of-Scope-Liste der Anforderung nennt sie.

**Keine Mindestzahl.** Ein Slice mit *einem* echten Ausschluss ist besser als
einer mit vier erfundenen; die vier Klassen sind ein Suchraster, keine
Ausfüll-Liste. Suchreihenfolge: Was übernimmt ein **Folge-Slice** (mit
Kennung — und die Kennung muss den Punkt auch annehmen)? Was bleibt als
**Bestand** bewusst stehen (mit Begründung)? Was wäre ein **anderer Vorgang**?
Welche **Schicht** rührt der Slice nicht an?

Was hier steht, ist die Grenze, an der ein wachsender Slice sich messen lässt:
Wer später etwas mitnimmt, das hier ausgeschlossen war, hat den Plan
**geändert**, nicht nur ergänzt.

## 2. Definition of Done

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Slice — **≤ 3 Liefer-Punkte**; mehr heißt: der Slice ist zu groß und
gehört zurück zur Zerlegung. Gezählt wird nur, was mit dem Umfang wächst — die
Gate-Läufe und die fünf Closure-Pflichten darunter zählen nicht mit.

- [x] **Lastenheft:** die Anforderung des Moduls mit Beschreibung (inkl. der
      §3.8-Grenze), Out-of-Scope, Akzeptanzkriterien, Bereichskürzel in §3, Version und
      Historie-Zeile ([`MR-032`](../../../../../harness/conventions.md#mr-032)); die neun Entscheide aus §1 sind gesetzt.
      **Ohne** Modulsatz in [`DC-FA-CLI-002`](../../../../../spec/lastenheft.md#dc-fa-cli-002--regelmodul-auswahl) und ohne Glossar-Zeile (§1).
- [x] **Spezifikation:** Schema `metrics.*` (§2), Block-Syntax, Formel samt
      Rundungsregel, Messsemantik der Summe, die Grund-Codes **im Verfahren** (§1) — die
      Zeilen der Tabelle in §4 und der `--doctor`-Klartext kommen mit der Umsetzung des
      jeweiligen Codes, weil `TestAllReasonsDeckungGegenSpezifikationGrundCodes` die Tabelle
      gegen `AllReasons()` hält; dazu die Schärfung von `spec/architecture.md`
      ([`ARC-005`](../../../../../spec/architecture.md), [`ARC-010`](../../../../../spec/architecture.md), Fehlerzeile) für den Zuwachs am VCS-Port (Entscheid 8).
- [x] **ADR** mit Alternativen-Tabelle zu den Entscheiden 1–9, Re-Evaluierungs-Trigger,
      `Schärft:`-Feld; ADR-Index nachgezogen ([`AGENTS.md`](../../../../../AGENTS.md) §5 Zeilen 4/5).
      **Status `Proposed` bis zur Closure von [`slice-284`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle)** — dort wird die `numstat`-Zusage
      belegt oder korrigiert; erst danach `Accepted`. Sonst bräuchte eine Korrektur
      eine Folge-ADR ([`AGENTS.md`](../../../../../AGENTS.md) §3.5).
- [x] Bestands-Gegenprobe an den Angaben des Anlass-Repos dokumentiert (§3): Block,
      Formel, Zustände und Messregeln aus dem Issue-Kommentar vom 2026-10-30 sind in der
      Anforderung belegt, die Prüfvorlage steht als Tabelle in der Closure-Notiz. Das
      Repo selbst ist **nicht gelesen**; die Anforderung kennzeichnet, was aus
      Angaben stammt und nicht am Repo gemessen ist (§3.8).
- [x] `make gates` grün.
- [x] Review durchgeführt, Report unter `docs/reviews/` liegt vor
      (`.harness/skills/reviewer.md`) — Rollenwechsel nach Schritt 8 des
      Minimal Agent Workflow (`AGENTS.md` §6), kein Self-Review (Modul 8).
- [x] Doku-Update: Benutzerhandbuch und `operations.md` **nicht** (Release-Prep, §1).
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag.
- [x] Beobachtungs-Register (`../../observations/`) fortgeschrieben — neues Verzeichnis `BEO-<KUERZEL>/<slug>/` oder eine weitere Datei in dessen `evidence/`; **kein Zaehler wird gesetzt**, er folgt aus den Dateien. Keine Beobachtung angefallen ist ebenfalls eine Antwort und wird in §7 notiert.
- [x] Jedes Risiko aus §6 trägt einen Ausgang (eingetreten / entfallen / weiter offen).
- [x] Die drei Paarungen (Anker · Folge-Slice · Register) sind getragen — von der nächsten Welle-Closure (auch für Slices ohne Wellen-Zugehörigkeit).

## 3. Plan (vor Code)

Regeln dieser Sektion: Baseline-Regelwerk `grundlagen-bootstrap.md`
§Was ist eine Sub-Area? — diese Liste liefert die **Pfad-Kandidaten** für §8,
nicht die Antwort: Pfad-Berührung ist nicht hinreichend, und eine
Aussagen-Berührung steht hier gar nicht.

| Datei / Komponente | Änderungs-Art | Begründung |
|---|---|---|
| `spec/lastenheft.md` | update | neue Anforderung des Moduls; §3 Bereichskürzel-Liste ([`MR-025`](../../../../../harness/conventions.md#mr-025): Spiegel vor dem Editieren auflisten); Version, Historie-Zeile. **Nicht:** Modulsatz in [`DC-FA-CLI-002`](../../../../../spec/lastenheft.md#dc-fa-cli-002--regelmodul-auswahl), Glossar-Zeile (→ [`slice-283`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle)) |
| `spec/spezifikation.md` | update | Schema-Zeilen `metrics.*`, Algorithmus-Abschnitt zur Anforderung (Grund-Codes im Text), Historie. **Nicht:** Zeilen in der Tabelle von §4 (→ Umsetzung, siehe DoD) |
| `spec/architecture.md` | update | [`ARC-005`](../../../../../spec/architecture.md), [`ARC-010`](../../../../../spec/architecture.md) und Fehlerzeile nennen `metrics` und die Zeilen-Zählung am Adapter; ohne Modul-Pfade ([`MR-033`](../../../../../harness/conventions.md#mr-033)) |
| `docs/plan/adr/` · `docs/plan/adr/README.md` | neu · update | ADR zu Entscheid 1–9 (Alternativen-Tabelle), Status `Proposed`, Index nachgezogen |

**Bestands-Gegenprobe vor dem Schreiben (nicht danach):**

- Die Angaben des Anlass-Repos (Issue-Kommentar vom 2026-10-30) gegenlesen: Block-Syntax,
  Feldnamen, Formel, Zustände, Messregeln. Ergebnis ist eine Tabelle Plan → Eingaben →
  Marke → Messung → Urteil, die der Slice-Closure-Notiz anhängt; sie ist zugleich die
  Vorlage für die Testfälle von [`slice-283`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) und die Paritäts-Probe in
  [`welle-93`](../welle-93-metrics-modul.md) §3. **Belegt sind** (Schätzung ⇒ Marke) das durchgerechnete
  Beispiel (6790 ⇒ 9200), die Grenzfälle (2000 ⇒ 2700, 2001 ⇒ 2800, 2222 ⇒ 3000,
  2223 ⇒ 3100 mit Schnittfrage), die Slices A (5036 ⇒ 6800), B (5430 ⇒ 7400) und
  C (9215 ⇒ 12500) und der Plan mit 4670 ⇒ 6400. B und C rechnen mit dem vor dem Code
  erwarteten Produktcode (1500, 2000), nicht mit dem Wert am Ende — die Rückfrage im
  Issue ist beantwortet. Die 16 Überschreitungen der Prosa-Zeit haben kein
  Urteil des Programms und sind keine Prüfvorlage.
- Der eigene Bestand dieses Repos trägt keinen solchen Block; die Probe „kein Block ⇒
  kein Befund“ folgt in [`slice-283`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle).
- Das Modul zählt über den VCS-Port; ob die Summe mit `git diff --numstat
  --no-renames` übereinstimmt, ist **nicht** hier zu messen, sondern in
  [`slice-284`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) am Fixture — hier nur als Zusage formuliert und als solche gekennzeichnet.

## 4. Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Trigger je Lifecycle-Übergang und WIP-Limit.

**Start** (`next` → `in-progress`): welle-93 ist offen, das WIP-Limit ist frei, und
der Auftraggeber hat die offenen Entscheide aus [`welle-93`](../welle-93-metrics-modul.md) §5
beantwortet oder die Empfehlungen aus §1 (Entscheide 1–9) bestätigt — Entscheide 5
und 9 hat der Issue-Autor im Kommentar vom 2026-10-30 (14:49) gesetzt —, **und** die
Angaben des Anlass-Repos liegen im Issue vor (erledigt, Kommentar vom 2026-10-30).
Der Übergang landet auf dem Hauptzweig, vor der Arbeit.

**Rückführungen — vorab benennen, nicht erst im Nachhinein begründen:**

- `in-progress` → `next` (zu groß, zurück zur Zerlegung): die Gegenprobe zeigt eine
  Fachlogik jenseits der Formel mit einer Aufrundung und der Schwellenregel (Verzweigung
  nach Zustand, mehrere Messgrößen) — dann gehört die Formel-Sprache in einen eigenen Slice vor diesem.
  Ebenso, wenn das Tabellenformat des Anlass-Repos sich nicht konfigurierbar ausdrücken lässt:
  dann gehört die Tabellen-Sprache in einen eigenen Slice vor [`slice-285`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle), oder wenn die Block-Form doch YAML
  verlangt und Entscheid 6 auf den Parse-Port fällt.
- `in-progress` → `open` (blockiert — Carveout?): der Auftraggeber entscheidet die
  Basis (Entscheid 2) so, dass sie nicht aus dem Plan stammt, oder die Angaben des
  Anlass-Repos erweisen sich bei der Ausarbeitung als widersprüchlich.

## 5. Closure-Trigger

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Closure- und Lerneintrag-Regeln — zwei beobachtbare Kriterien **und** ein
Lerneintrag; ohne ihn ist der Slice nur abgelegt.

DoD vollständig, `make gates` grün (darunter `doc-check`, `adr-check`,
`gate-consistency`), Review-Report liegt vor, und die Gegenprobe-Tabelle (§3) steht
in der Closure-Notiz. Dazu die Closure-Notiz mit Lerneintrag.

## 6. Risiken und offene Punkte

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Offene Risiken werden bei Closure aufgelöst — **jedes** Risiko bekommt genau
**einen** Ausgang, und kein Slice geht nach `done/`, während eines ohne Ausgang
dasteht.

- Die Fachlogik des Anlass-Repos passt nicht in die zweistufige Formel samt
  Schwellenregel und das Tabellenformat (etwa wenn weitere Pläne ein anderes Format tragen); eine zu enge
  Anforderung zwingt das Anlass-Repo, sein Programm zu behalten, und das Modul wäre
  ohne Konsumenten — **Ausgang:** weiter offen — die Zahlen und das Format stammen aus Angaben, nicht aus einer Messung am Anlass-Repo; die Paritäts-Probe des Eigentümers entscheidet ([`BEO-ALL/eigene-menge-gemessen-fremde-behauptet`](../../observations/BEO-ALL/eigene-menge-gemessen-fremde-behauptet/observation.md))
- Die Anforderung beschreibt die Messung per `numstat`-Gleichheit, bevor der Adapter
  steht; ein Unterschied zwischen reiner-Go-Diff und git-Kommando (Zeilenenden,
  Binärdateien, große Dateien) würde sie nachträglich ändern. Die Zusage ist
  deshalb als noch nicht belegt gekennzeichnet — **Ausgang:** weiter offen — die Gleichheit mit `numstat` belegt erst die Messung am Fixture; die ADR bleibt bis dahin `Proposed` (Folge: [`slice-284`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle))
- Die Angaben sind anonymisiert und vom Eigentümer selbst zusammengestellt; Stand und
  Pläne des Anlass-Repos ändern sich bis zur Paritäts-Probe, und die Tabelle misst
  dann einen alten Stand oder eine Auswahl — **Ausgang:** weiter offen — die Rückmeldung des Eigentümers an der veröffentlichten Version steht im Closure-Trigger der Welle

## 7. Closure-Notiz

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Das Beobachtungs-Register (vorhandene `BEO-<KUERZEL>/<slug>` **zitieren** statt neu
formulieren — sonst zählt das Register zwei Namen getrennt) ·
`grundlagen-traceability.md` §Herkunfts-Anker für Steering-Loop-Regeln (das
Feld `liegt in` steht **nur**, wenn mit diesem Slice wirklich etwas verkörpert
wurde; Feld und Zielort auf **einer** Zeile, Sektionsangabe innerhalb der
Backticks). Ging der Gegenstand an einen anderen Slice oder entfiel er, trägt
diese Sektion die Zeile `Gegenstand:` mit Kennung oder Grund und jedes Risiko
aus §6 seinen Ausgang; die Liefer-Punkte der DoD bleiben leer
(`modul-05-planning-harness.md` §Ein Slice, dessen Gegenstand ein anderer
übernimmt).

- **Geliefert:** die Anforderung [`DC-FA-MET-001`](../../../../../spec/lastenheft.md#dc-fa-met-001--kennzahl-eines-planungsdokuments-gegen-messung-aus-git-modul-metrics-opt-in)
  (Lastenheft 0.110.0), das Verfahren [`DC-FA-MET-001.a`](../../../../../spec/spezifikation.md#dc-fa-met-001a--kennzahl-eines-planungsdokuments-gegen-messung-aus-git-metrics) mit Schema `metrics.*` in der Spezifikation, die
  Schärfung von [`ARC-005`](../../../../../spec/architecture.md), [`ARC-010`](../../../../../spec/architecture.md) und der Fehlerzeile in der Architektur und die ADR
  [`ADR-0112`](../../../adr/0112-metrics-modul.md) (`Proposed`). Modulsatz in
  [`DC-FA-CLI-002`](../../../../../spec/lastenheft.md#dc-fa-cli-002--regelmodul-auswahl) und Glossar fehlen absichtlich: der Spiegel-Test hält sie gegen
  `ValidModules()`, das Modul ist noch nicht registriert.
- **Bestands-Gegenprobe (Quelle: Angaben des Issue-Autors, nicht das Repo):** Schätzung → Marke nach
  `100 · ⌈135 · S / 10000⌉`, Schwelle `135 · S > 300000`; alle Paare von Hand und vom Reviewer wie vom Verifier nachgerechnet.

  | Fall | Schätzung | Marke | Schwellenregel |
  |---|---|---|---|
  | durchgerechnetes Beispiel | 6790 | 9200 | ja |
  | Slice A | 5036 | 6800 | ja |
  | Slice B (erwarteter Produktcode 1500) | 5430 | 7400 | ja |
  | Slice C (erwarteter Produktcode 2000) | 9215 | 12500 | ja |
  | Plan mit Messpunkt 5342 | 4670 | 6400 | ja |
  | Grenzfall | 2000 | 2700 | nein |
  | Grenzfall | 2001 | 2800 | nein |
  | Grenzfall | 2222 | 3000 | nein |
  | Grenzfall | 2223 | 3100 | ja |

  Slices B und C waren erst unstimmig (der Autor gab den Produktcode am Ende statt des erwarteten an); die
  Rückfrage im Issue klärte es. Die 16 Überschreitungen der Prosa-Zeit haben kein Urteil des Programms und sind
  keine Prüfvorlage.
- **Was anders lief als geplant:** (1) Der Autor kehrte im Verlauf Entscheid 9 um: die Tabellenzählung gehört ins
  Modul, daher der neue Slice [`slice-285`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle). (2) `TestAllReasonsDeckungGegenSpezifikationGrundCodes` hält die
  Grund-Code-Tabelle der Spezifikation gegen den Code; die Zeilen kommen mit der Umsetzung der Slices
  283, 284 und 285 (Plan-Änderung vor dem Inhalt). (3) Review R1 (6 MEDIUM) und R2 (3 MEDIUM) fanden vor allem
  Leseweisen, die der Text „wie die übrigen Module“ nannte, ohne dass es eine gemeinsame gab.
- **Steering-Loop-Eintrag:** keiner mit neuer Schwelle. Benannte Spec-Lücke: Zäune und Tabellenzeilen haben im
  Produkt zwei Leser-Familien (siehe Register); die Spezifikation von `metrics` legt die RTM-Familie fest.
- **Beobachtungs-Register (`../../observations/`):**
  [`module-promise-only-on-scan-axis`](../../observations/BEO-ALL/module-promise-only-on-scan-axis/observation.md)
  bekommt einen weiteren Beleg (Pfad ohne Treffer zählt still 0, Review R1 F-4); neu angelegt
  [`gemeinsame-leser-sind-zwei-familien`](../../observations/BEO-ALL/gemeinsame-leser-sind-zwei-familien/observation.md) (1×).
- **Folge-Slices:** [`slice-283`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle), [`slice-284`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) und [`slice-285`](../welle-93-metrics-modul.md#4-slices-in-dieser-welle) in `open/`.
- **Plan-Schärfung (V-2 der Verifikation):** der Hinweis zum Pfad ohne Treffer steht jetzt in §1 Entscheid 4.
- **Risiken aus §6:** alle drei weiter offen (siehe §6), jedes mit Verweis. Trigger-Audit: kein Carveout, kein
  bootstrap-aware Gate, keine bestehende ADR mit eingetretenem Trigger (die neue [`ADR-0112`](../../../adr/0112-metrics-modul.md) bleibt `Proposed`), keine
  Hard Rule mit eingetretenem Trigger, keine Schwelle gesenkt.
- **Drei Paarungen:** (a) Anker — kein `liegt in`-Feld; (b) Folge-Slice — die genannten Slices liegen in `open/`;
  (c) Register — die zitierten Beobachtungen existieren und tragen Belege.

## 8. Sub-Area-Prüfungen und Modus-Begründung

Regeln dieser Sektion: Baseline-Regelwerk `modul-05-planning-harness.md`
§Ziel-Form: Sub-Area-Modus-Begründung — dort die **zwei vorgelagerten
Schritte** (sie stehen in jedem Slice-Plan, unabhängig von Modus und
Slice-Typ) und die **vier Pflichtkriterien** (Konventionen-Dichte ·
Phase-Reife · Evidenz-/Diskrepanz-Risiko · Reconciliation-Aufwand), vier und
nicht mehr.

**Der Abschnitt selbst entfällt nie.** Die zwei vorgelagerten Prüfungen laufen
in **jedem** Slice-Plan — sie hängen weder am Modus noch am Slice-Typ. Bedingt
ist allein der Modus-Begründungsblock am Ende; deshalb nennt der Titel beide
Hälften.

<!-- d-check:cite .harness/baseline/v6.18.1/regelwerk/modul-05-planning-harness.md:373-374 -->

> **Sub-Area-Wahl prüfen.** Jede Sub-Area, die der Slice als berührt führt,
> muss das Inklusionskriterium erfüllen — drei Achsen, Schwelle ≥ 2

**Vorgelagert — Sub-Area-Wahl prüfen:** berührt ist der Default `*` (`ALL`) —
Spec und ADR; keine Sub-Area mit eigener Modus-Deklaration.

<!-- d-check:cite .harness/baseline/v6.18.1/regelwerk/modul-05-planning-harness.md:379-379 -->

> **Offene Beobachtungen sichten.** Das

**Vorgelagert — offene Beobachtungen sichten:** Register durchgegangen, Sub-Area
`*`. Treffer:
[`BEO-ALL/module-promise-only-on-scan-axis`](../../observations/BEO-ALL/module-promise-only-on-scan-axis/observation.md)
(3×, verkörpert in [`AGENTS.md`](../../../../../AGENTS.md) §3.8 — das Modul liest Pfade und
git-Revisionen, die es nicht scannt; die Grenze steht in der Anforderung, §1) und
[`BEO-ALL/eigene-menge-gemessen-fremde-behauptet`](../../observations/BEO-ALL/eigene-menge-gemessen-fremde-behauptet/observation.md)
(17×, gemischt — die Gegenprobe stützt sich auf die Angaben des Anlass-Repos, nicht auf den Eigenbestand,
der keinen Block trägt; die Anforderung sagt, was am Fremdbestand gemessen ist und
was nur behauptet). Der Zähler folgt aus den Dateien der Closure.

**Vorgelagert — Nachtlauf-Stand lesen** ([`MR-053`](../../../../../harness/conventions.md#mr-053)):
`make nightly-state` am 2026-10-30: `upstream-drift` grün (jüngster Lauf 2026-10-30T06:41:15Z), `image-scan`
grün (2026-10-30T10:04:41Z). Nichts zu lesen, nichts ausstehend.

### Sub-Area: `*` (Default)

Alle berührten Sub-Areas GF.

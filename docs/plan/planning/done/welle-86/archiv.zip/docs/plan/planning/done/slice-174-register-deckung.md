# Slice slice-174: Die Register-Deckung bekommt ihren Wächter

**Lifecycle:** Der Zustand dieses Slice ist das **Verzeichnis** (`open/`/`next/`/
`in-progress/`/`done/`), bewegt per `git mv` — kein Status-Feld.
**Welle:** [welle-86](welle-86-closure-uebergang-durchsetzen.md) — dritter
von vier Slices. Ihr Closure-Trigger fordert einen Beleg, den keine einzelne
DoD liefert: dass die Vorbedingungen **am Übergang** greifen.

**Bezug:** [`DC-FA-PLAN-001`](../../../../spec/lastenheft.md#dc-fa-plan-001--planning-lifecycle-konsistenz-modul-planning-opt-in)
(das Planning-Modul, mögliche Heimat der Bedingung);
[ADR-0028](../../adr/0028-planning-lifecycle-modul.md) (seine Bauform).
Der Kanon nennt die maschinelle Hälfte selbst — Baseline-Regelwerk
`modul-06-roadmap.md` §Das Beobachtungs-Register.

**Berührte Spec-Stellen:**
[`DC-FA-PLAN-001`](../../../../spec/lastenheft.md#dc-fa-plan-001--planning-lifecycle-konsistenz-modul-planning-opt-in)
oder eine neue `DC-FA-*`-Anforderung — die Wahl ist Teil des Slice (§2), und mit
ihr die `.a`-Verfeinerung in der
[Spezifikation](../../../../spec/spezifikation.md).

**Verantwortlich:** pt9912.

**Autor:** pt9912. **Datum:** 2026-08-31.

---

## 1. Ziel

**Das Beobachtungs-Register ist die einzige Deckungs-Prüfung des Steering
Loops, die der Kanon ausdrücklich als maschinell entscheidbar benennt — und
niemand hat sie gebaut.** Der Kanon trennt sauber: *Mensch urteilt, Maschine
prüft Deckung.* Geprüft werden kann, ob eine in `done/` zitierte `BEO-<NNN>`
eine Registerzeile hat; **nicht** geprüft wird die Umkehrung („jede Zeile ist
irgendwo zitiert"), weil die allermeisten unter der Schwelle stehen.

**Gemessen am eigenen Bestand, 2026-08-31 — der Wächter wäre heute grün:**

| Messung | Ergebnis |
|---|---|
| in `done/` zitierte Kennungen | **24** |
| davon ohne Registerzeile | **0** |
| Registerzeilen (Haupttabelle) | 22, dazu 2 gestrichene |

**Ein grüner Wächter ist hier kein Argument gegen ihn, sondern für ihn:** ein
erfundenes `BEO-999` in einer Closure-Notiz fiele heute niemandem auf, und die
Zeile, die es belegen soll, gäbe es nicht. Die Deckung ist gelebte Praxis ohne
Sensor — genau die Lage, die
[welle-86](welle-86-closure-uebergang-durchsetzen.md) für den ganzen
Closure-Übergang beschreibt.

## 2. Vorgehen

1. **Die Richtung festlegen und begründen:** geprüft wird **Zitat ⇒ Zeile**,
   nicht die Umkehrung. Der Kanon schließt die Umkehrung ausdrücklich aus; das
   gehört in die Anforderung, nicht nur in den Plan.
2. **Die Scan-Menge entscheiden.** Der Kanon sagt „in `done/` zitiert".
   Gemessen wird die Kennung aber auch in [`AGENTS.md`](../../../../AGENTS.md),
   in `MR-`Dateien und in `open/`-Slices. Ob die Prüfung dort mitgilt, ist eine
   Entscheidung mit Folgen — und sie gehört nach
   [`AGENTS.md`](../../../../AGENTS.md) §3.8 in die Anforderung, weil ein Modul
   nur über das verspricht, was es scannt.
3. **Den Träger wählen — zwei Kandidaten, die Wahl ist zu messen, nicht zu
   setzen.** (a) Eine Bedingung im vorhandenen Modul `planning`: es prüft
   bereits „Doku-Behauptung ↔ Repo-Struktur", hermetisch, und das Register
   liegt in seinem Layout. (b) Ein eigenes Modul `registry`: diese Form ist im
   Register selbst vorgezeichnet ([`BEO-001`](../observations.md), gestrichen)
   — *ein Verzeichnis-Muster je Register plus Autoritäts-Datei, eine Richtung,
   ein Grund-Code* — und deckte später den ADR-Index und den
   Konventionsspeicher-Index mit. Kriterium: trägt die dritte Anwendung genug,
   um ein Modul zu rechtfertigen, oder ist sie Spekulation?
4. **Nicht über `ids`.** Der naheliegende Weg — Kennung als Linkpflicht auf
   einen Anker je Registerzeile, wie `version.md` es für Versionen tut — ist
   **gemessen verworfen**: 1450 Nennungen im Baum, davon 1042 nackt, allein 708
   in `done/` und 626 in `docs/reviews/`. Das Retrofit schriebe eingefrorene
   Lauf-Belege um. Die Messung gehört in die ADR, damit der Weg nicht zweimal
   geprüft wird.
5. **Umkehr-Probe vor dem Scharfschalten:** ein konstruiertes `BEO-999` in
   einer Closure-Notiz muss melden, und der heutige Bestand muss grün bleiben —
   beide Zahlen mit Ausgabe.
6. **Vertrag und Doku:** Anforderung (neu oder erweitert), `.a`-Verfeinerung
   samt Grund-Code, ADR für die Entscheide aus 2–4, Aktivierung im eigenen
   Profil, Handbuch.
7. `make gates` und `make fullbuild`; **Review** und **Verifikation** als
   getrennte Läufe; Closure.

## 2a. Getroffene Entscheidungen (mit ihrer Messung)

**Träger: eine vierte Fähigkeit im vorhandenen Modul `planning`, kein eigenes
Modul.** `planning` besitzt bereits das Layout, den hermetischen Vertrag und
die Bauform „opt-in **innerhalb** des opt-in Moduls" (so ist `waves`
geschnitten). Ein Modul `registry` rechtfertigte sich mit zwei weiteren
Registern (ADR-Index, Konventionsspeicher-Index), die heute niemand prüft —
das ist eine Aussage über künftigen Bedarf und damit genau
[`BEO-011`](../observations.md). Fällt die dritte Anwendung wirklich an, ist
die Verallgemeinerung dann mit Bestand zu begründen, nicht jetzt mit einer
Vermutung.

**Scan-Menge: der Planning-Baum, nicht nur `done/` — und die Grenze ist
gemessen.** Der Kanon sagt „in `done/` zitiert"; im Baum stehen Kennungen aber
auch in `open/` (7) und `in-progress/` (9). Eine Behauptung über eine
Registerzeile wiegt dort genauso. **Ausgenommen bleibt `docs/reviews/`**: das
sind Lauf-Belege fremder Rollen, eingefroren, und dort steht mit `BEO-099` ein
weiteres Beispiel.

**Erkennungs-Form: Prosa und Linktext zählen, ein reines Inline-Code-Span
nicht.** Das ist die Unterscheidung, die `ids` bereits trifft (*ein
Code-Span-Vorkommen ist linkpflichtfrei, wenn es im Linktext liegt*), und sie
ist hier zwingend: gemessen im Planning-Baum stehen **366** echte Zitate als
`[`BEO-NNN`](…)`, also **mit** Backticks im Linktext. Eine Regel „Inline-Code
zählt nicht" übersähe genau sie. Umgekehrt sind beide gefundenen Beispiel-Nennungen
(`BEO-999` hier, `BEO-099` in einem Review) reine Code-Spans.

**Verworfen, gemessen: der `ids`-Weg.** Kennung als Linkpflicht auf einen Anker
je Registerzeile — wie `version.md` es für Versionen tut — bräuchte drei
Retrofits: Anker in 22 Zeilen (klein), `#beo-NNN` in 366 bestehende Links
(groß) und Links für 293 Prosa-Nennungen allein im Planning-Baum (groß). Die
letzten beiden schrieben eingefrorene Lauf-Belege um.

**Gegenprobe vor dem Bau:** unter dieser Regel hat der heutige Baum **null**
Waisen — die einzige Fundstelle ohne Registerzeile ist das Beispiel `BEO-999`
in diesem Plan, und es liegt in Backticks.

## 3. Ausdrücklich NICHT in diesem Slice

- **Die Beleg-Form-Prüfungen (Form · Anzahl · Lage).** Sie gehören zur selben
  Kanon-Stelle, aber nicht in diesen Schnitt. **Lage** deckt bereits `links`
  (alle 21 Beleg-Zellen sind `done/`-Links). **Form** ist erfüllt, aber
  ungewächtert. **Anzahl** ist die einzige echte Lücke — und sie ginge auf dem
  Bestand rot: [`BEO-023`](../observations.md) trägt Zähler 7 bei sechs
  eindeutigen Slices, [`BEO-004`](../observations.md) Zähler 3 bei einem. Beide
  Abweichungen sind **in der Zeile begründet** — und der Grund dafür ist
  **während dieses Slice weggefallen**: die Quelle des Kanons hat inzwischen die
  zwei Regeln gesetzt, die den Fall entscheiden (zwei Funde im selben Vorgang
  sind eine Gelegenheit; ein Vorkommen ohne abgeschlossenen Vorgang bewegt den
  Zähler nicht). Damit sind die zwei Zeilen **keine begründeten Abweichungen
  mehr, sondern zu hoch gezählt** — 6 statt 7, 1 statt 3. **Der Ausschluss
  bleibt richtig, seine Begründung ist eine andere:** die Anzahl-Achse braucht
  einen Bestand, der die Regel erfüllt, und den stellt
  [slice-188](../done/slice-188-register-gegen-neuen-kanon.md) her. Eine
  Bestands-Ausnahme wie [`MR-049`](../../../../harness/conventions.md#mr-049)
  oder [`MR-056`](../../../../harness/conventions.md#mr-056) braucht es
  **nicht** — das war meine Einschätzung, solange die Regel fehlte, und sie ist
  überholt.
- **Die Umkehrung** („jede Zeile ist zitiert"). Der Kanon schließt sie aus.
- **Das Urteil, ob zwei Beobachtungen dieselbe sind.** Mensch.
- **Das Nachrüsten von Bestands-Zitaten.** Es gibt nichts nachzurüsten: 24 von
  24 sind gedeckt.

## 4. Definition of Done

- [x] Eine in `done/` zitierte `BEO-<NNN>` **ohne** Registerzeile erzeugt einen
      Befund mit eigenem Grund-Code; die Richtung und die **Scan-Menge** stehen
      in der Anforderung, nicht nur im Code.
- [x] **Umkehr-Probe gemessen:** konstruiertes `BEO-999` ⇒ Befund; eigener
      Bestand ⇒ 0 Befunde. Beide Ausgaben in der Closure-Notiz.
- [x] Träger-Entscheid (`planning`-Bedingung gegen eigenes Modul) **begründet**
      in einer ADR, samt der gemessenen Verwerfung des `ids`-Wegs.
- [x] Anforderung, `.a`-Verfeinerung mit Grund-Code, Profil-Aktivierung und
      Handbuch sind nachgezogen.
- [x] `make gates` und `make fullbuild` grün (Exit explizit); **unabhängiger
      Review**; **Verifikation** — beide in eigenen Kontexten.
- [x] Closure-Notiz mit Steering-Loop-Lerneintrag; Beobachtungs-Register
      fortgeschrieben; jedes Risiko aus §5 mit Ausgang; die drei Paarungen
      geprüft.

## 5. Abnahme-Punkte / Risiken

- **Der Wächter ist von Anfang an grün.** Er verhindert eine Klasse, die noch
  nie eingetreten ist — genau die Lage, in der ein Sensor später für überflüssig
  gehalten und entfernt wird ([`BEO-013`](../observations.md), Zähler 1). Die
  Anforderung muss sagen, **wovor** er schützt, nicht nur was er prüft.
  — **Ausgang:** *entfallen* — gemessen, nicht zugesagt: die Anforderung sagt,
  wovor er schützt, und die Gegenprobe zeigt, **dass** er greift. Eine
  umbenannte Registerzeile erzeugt sofort Befunde in jeder zitierenden Datei,
  nach dem Zurückstellen wieder null. Ein grüner Wächter, von dem niemand
  weiß, ob er fangen kann, wäre [`BEO-023`](../observations.md).
- **Die Scan-Menge ist die eigentliche Entscheidung.** Zählt nur `done/`, ist
  ein erfundenes `BEO-999` in einem `open/`-Slice oder in
  [`AGENTS.md`](../../../../AGENTS.md) weiter unsichtbar; zählt alles, meldet
  die Prüfung womöglich in Dokumenten, die gar keine Belege führen sollen.
  — **Ausgang:** *entfallen* — entschieden und begründet: der **Planning-Baum**
  statt nur `done/` (Kennungen stehen auch in `open/` und `in-progress/`),
  `docs/reviews/` bleibt außen (eingefrorene Lauf-Belege fremder Rollen). Die
  Grenze steht in der Anforderung, nicht nur im Code
  ([`AGENTS.md`](../../../../AGENTS.md) §3.8).
- **Ein eigenes Modul auf Vorrat.** Kandidat (b) rechtfertigt sich mit zwei
  weiteren Registern, die heute niemand prüft. Das ist eine Aussage über
  künftigen Bedarf — [`BEO-011`](../observations.md), Zähler 5, ist genau die
  Klasse „Regel aus dem Anlass statt aus dem Bestand". — **Ausgang:**
  *entfallen* — das Modul ist **nicht** gebaut worden. Die vierte Fähigkeit
  liegt in `planning`, und die Ablehnung samt ihrer Umkehrbedingung steht in
  [ADR-0079](../../adr/0079-register-deckung-zaehlt-linktext.md).
- **Die Beleg-Form bleibt liegen**, und mit ihr die zwei begründeten
  Abweichungen. Wer den Slice liest, könnte die Deckung für die ganze
  maschinelle Hälfte halten. — **Ausgang:** *eingetreten* → Folge-Slice
  [slice-188](../done/slice-188-register-gegen-neuen-kanon.md). Er bringt den
  Bestand mit der neuen Beleg-Definition in Übereinstimmung; erst danach ist
  die Anzahl-Achse baubar. Die Abgrenzung steht in §3 dieses Plans.

## 6. Trigger

**Start** (`open` → `in-progress`): WIP-Limit frei — `in-progress/` trägt keinen
Slice.

**Rückführungen:** `in-progress` → `next`, falls der Träger-Entscheid auf ein
eigenes Modul fällt — dann wächst der Slice über drei Liefer-Punkte hinaus
(Modul, Vertrag, Profil, Handbuch) und gehört neu geschnitten.
`in-progress` → `open`, falls die Scan-Mengen-Frage eine Kanon-Entscheidung
verlangt, die wir nicht allein treffen können.

## 7. Vorgelagert (vor der Modus-Begründung)

- **Sub-Area prüfen:** `internal/hexagon/core/rules` (die Bedingung), `spec/`
  (Anforderung und Verfeinerung) und `docs/plan/planning/` (das geprüfte
  Artefakt). Alle drei fallen unter den Default `*` = **Greenfield**
  ([`harness/conventions.md`](../../../../harness/conventions.md)
  §Modus-Deklaration pro Sub-Area). Die Regel, die diesen Schritt vorschreibt:

  <!-- d-check:cite .harness/baseline/v5.12.0/regelwerk/modul-05-planning-harness.md:213-214 -->
  > **Sub-Area-Wahl prüfen.** Jede Sub-Area, die der Slice als berührt führt,
  > muss das Inklusionskriterium erfüllen — drei Achsen, Schwelle ≥ 2

- **Offene Beobachtungen sichten** (Register-Stand 2026-08-31, höchste Kennung
  `BEO-024`): [`BEO-013`](../observations.md) (Zähler 1) — *ein Wächter, der
  nichts mehr fängt, bleibt stehen*; hier eine Stufe früher, weil dieser
  Wächter von Anfang an nichts fängt, und deshalb als Risiko geführt;
  [`BEO-011`](../observations.md) (Zähler 5) — die Rechtfertigung eines eigenen
  Moduls mit künftigem Bedarf ist genau diese Klasse;
  [`BEO-015`](../observations.md) (Zähler 3) — *ein offener Punkt bekommt bei
  der Closure einen Ausgang, den es nicht gibt*: dieselbe Familie urteilsfreier
  Closure-Prüfungen, die dieser Slice erweitert;
  [`BEO-002`](../observations.md) (Zähler 7) — die Spiegel-Frage trifft hier
  die Anforderung, deren Scan-Menge an mehreren Stellen stehen wird. Die Regel,
  die diesen Schritt vorschreibt:

  <!-- d-check:cite .harness/baseline/v5.12.0/regelwerk/modul-05-planning-harness.md:219-219 -->
  > **Offene Beobachtungen sichten.**

- **Nachtlauf-Stand lesen** (`make nightly-state`,
  [`MR-053`](../../../../harness/conventions.md#mr-053)): `upstream-drift.yml`
  meldet **ROT** (Lauf 2026-08-31T06:31:40Z), `image-scan.yml` grün
  (2026-08-31T09:48:33Z). Gelesen: die drei roten Schritte waren
  `baseline-freshness` (bekannt, [slice-183](../done/slice-183-baseline-v5150.md)),
  `freshness-a-check` und `go-base-digest` — **die letzten beiden sind seither
  behoben**, der Lauf ist nur noch nicht wiederholt worden. Das ist die
  benannte Grenze des Targets: es liest den **jüngsten** Lauf, nicht sein
  Alter. Keiner der drei berührt diesen Slice. **Dieser Block trägt bewusst
  keine `cite`-Direktive** — sein Ziel ist eine Repo-Adaption
  ([`MR-054`](../../../../harness/conventions.md#mr-054)).

Slice-ID: slice-174. Betroffene IDs:
[`DC-FA-PLAN-001`](../../../../spec/lastenheft.md#dc-fa-plan-001--planning-lifecycle-konsistenz-modul-planning-opt-in)
(möglicher Träger), [ADR-0028](../../adr/0028-planning-lifecycle-modul.md).
Module: `planning` oder neu. Gates: `make test`, `make planning-check`,
`make gates`, `make fullbuild`.

## 8. Sub-Area-Modus-Begründung

**GF (Greenfield, Repo-Default)** — alle drei berührten Sub-Areas fallen unter
den Default: Doc führt, Code folgt. Die Regel steht im Kanon, der Bestand ist
gemessen und konform (24/24), es gibt keine Reconciliation.

**Die GF-Reihenfolge wurde dabei NICHT eingehalten, und das gehört hierher statt
in eine milde Closure-Formulierung.** Gebaut wurde **code-first**: Regel, Tests
und Grund-Code standen, bevor Lastenheft und ADR nachgezogen wurden — der
Feat-Commit trägt die Spec-Änderung, der ADR-Commit folgt ihm. Doc führt heißt
Spec → ADR → Code, und das war hier umgekehrt.

**Der Grund ist nicht bloß Bequemlichkeit, und er entwertet die Abweichung
nicht:** die tragende technische Entscheidung — Prosa und Linktext zählen, ein
reines Inline-Code-Span nicht — **entstand beim Bau**. Erst die Messung am
Bestand (366 Zitate mit Backticks im Linktext gegen 112 reine Code-Spans) zeigte,
dass der naheliegende Präzedenzfall dieses Repos die Zitate übersehen hätte. Eine
doc-first geschriebene Anforderung hätte die falsche Regel zugesagt.

**Was daraus folgt, ist keine Ausnahme, sondern eine Reihenfolge-Korrektur für
den nächsten Fall dieser Art:** wo die tragende Regel von einer Messung am
Bestand abhängt, gehört die **Messung** vor die Anforderung — nicht der Code.
Der Slice hätte mit einer Mess-Etappe beginnen können und wäre danach doc-first
geblieben.
## 9. Closure-Notiz (nach `done/`)

- **Was hat funktioniert:** **Erst messen, dann entscheiden.** Die tragende
  Regel — Prosa und Linktext zählen, ein reines Inline-Code-Span nicht — kam
  aus einer Zählung am Bestand (366 / 293 / 112 / 5), nicht aus dem
  Präzedenzfall. Wäre ich dem gefolgt (*„Inline-Code zählt nicht"*, wie
  `citations` und die Platzhalter-Bedingung), hätte der Wächter **genau die
  Zitate übersehen**, um die es geht, und nur die Beispiele gemeldet. Ebenso
  getragen hat, den `ids`-Weg **gemessen** zu verwerfen (1450 Nennungen, 1042
  nackt) statt ihn zu erwägen — die Zahl steht in der ADR und muss nicht noch
  einmal erhoben werden.
- **Was ging anders als geplant:** Vier Dinge, und drei davon fand ein anderer.
  (1) **Code-first in einer GF-Sub-Area** — §8 sagt es aus, statt es hier zu
  mildern: gebaut wurde vor der Anforderung, weil die tragende Entscheidung
  beim Bau entstand. Die Korrektur für den nächsten Fall steht dort: wo die
  Regel von einer Messung abhängt, gehört die **Messung** vor die Anforderung,
  nicht der Code. (2) Der Review fand ein **HIGH**: zwei verschiedene
  ungedeckte Kennungen auf einer Zeile fielen in der Deduplikation zusammen —
  der Lauf blieb rot, aber die **Zahl** war falsch, also genau die Klasse,
  gegen die diese Fähigkeit gebaut ist. `ids` löst das seit jeher, und ich
  hatte das Muster nicht befolgt, obwohl ich in derselben Datei darauf
  verweise. (3) Die Verifikation fand ein **reproduzierbar falsches
  Handbuch-Beispiel**: §4.20 wies das gepinnte `v0.71.1` an, das den Schlüssel
  nicht kennt — `field observations not found`, Exit 2. (4) Die
  Profil-Aktivierung stand als *nachgezogen* in der DoD und war es nicht.
- **Steering-Loop-Eintrag:** keiner mit Zielort. Beide Lehren dieses Slice sind
  **gezählt, nicht verkörpert** — ein Wächter gegen übernommene Präzedenzen
  wäre ein Urteil, kein `grep`, und die Commit-Zuordnung sieht kein Sensor
  (`commits` prüft, **dass** eine Kennung dasteht, nicht ob es die richtige
  ist). Das als Verkörperung auszugeben wäre die Überdehnung, die
  [`BEO-012`](../observations.md) beschreibt.
- **Beobachtungs-Register (`../observations.md`):**
  [`BEO-012`](../observations.md) auf **12** erhöht — zweimal in diesem Slice,
  und beide Male war die gedehnte Quelle eine **Präzedenz** statt eines Textes
  (die aufgeschobene Aktivierung nach dem Vorbild `waves.mode: many`, dessen
  Anlass bei uns nachweislich fehlt; die gepinnte Version im Handbuch-Beispiel,
  aus den Nachbar-Aufgaben übernommen). **[`BEO-025`](../observations.md) neu
  angelegt** (Zähler 1): ein Liefer-Punkt landet im Commit eines **fremden**
  Slice — Handbuch §4.20 und die Modultabellenzeile liegen in `a4bc209`, dem
  Commit, der slice-187 schneidet.
- **Folge-Slices:**
  [slice-188](../done/slice-188-register-gegen-neuen-kanon.md) — er bringt den
  Register-Bestand mit der neuen Beleg-Definition in Übereinstimmung; erst
  danach ist die Anzahl-Achse baubar.
- **Risiken aus §5:** vier, jedes mit genau einem Ausgang — dreimal
  *entfallen* mit Begründung, einmal *eingetreten* mit Folge-Slice.
- **Drei Paarungen:** (a) **Anker** — kein `liegt in`-Feld, weil nichts
  verkörpert wurde; nichts zu paaren. (b) **Folge-Slice** — slice-188 existiert
  als Datei in `open/`. (c) **Register** — die zitierten Kennungen
  (`BEO-011`, `BEO-012`, `BEO-013`, `BEO-015`, `BEO-023`, `BEO-025`) haben je
  eine Zeile; **und das prüft ab jetzt der Wächter dieses Slice selbst**, scharf
  im eigenen Profil.

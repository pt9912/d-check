# Welle welle-84-durchsetzung: Neun Abschnitte, zehn Regeln — und ein Sensor, den niemand aufruft

**Lifecycle:** Diese Datei entsteht bei der **Eröffnung** und liegt **flach**
unter `docs/plan/planning/`; bei Closure wandert sie per `git mv` nach `done/`
(neben ihre `welle-84-results.md`). Der Zustand ist die Verzeichnis-Position —
kein Status-Feld.

**Zielmeilenstein:** kein Meilenstein-Bezug. Ob die Welle mit einem Release
schließt, entscheidet der Zensus — durchgesetzt wird zuerst mit dem, was schon
da ist.

**Verantwortlich:** pt9912. **Autor:** pt9912. **Datum:** 2026-08-23.

---

## 1. Welle-Ziel

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Wann Arbeit eine Welle braucht.

[`modul-09-implementierung.md` §AGENTS.md-Regeln](../../../../.harness/baseline/v5.11.0/regelwerk/modul-09-implementierung.md#agentsmd-regeln-modul-9)
sagt: *„Jede Hard Rule liegt in **zwei** Quadranten: inferential feedforward
(steht in AGENTS.md) + computational feedback (Fitness Function/Linter-Gate).
Hard Rule nur in einem Quadranten ist **halb durchgesetzt**."*

[`AGENTS.md`](../../../../AGENTS.md) §3 trägt **neun Abschnitte** — und
**zehn Regeln**: §3.7 bündelt zwei eigenständige Pflichten (Kommentar-Klassen
und Zustandsfelder). Dazu die Botschafts-Regel in §5. Elf Zeilen also, und der
Unterschied zwischen Abschnitt und Regel ist die Lehre aus slice-127. Für **drei** davon ist die Einseitigkeit belegt — sie
sind in welle-83 zugezogen und tragen kein Gate. Für die übrigen ist sie
**weder belegt noch widerlegt**: niemand hat je Regel für Regel gefragt, welcher
Gate-Lauf sie trägt.

**Der Anlass ist ein Fund, der zeigt, dass die Frage nötig ist.** Beim Sichten
der Werkzeuge des Schwester-Repos hat sich herausgestellt, dass
[`tools/harness/fetch-baseline-cache.sh`](../../../../tools/harness/fetch-baseline-cache.sh)
drei Fähigkeiten trägt — Integritätsprüfung des vendorten Bestands,
Currency-Audit gegen die Release-Liste, Content-Drift am gepinnten Tag — und
dass **kein `make`-Target, kein Workflow und kein Hook es aufruft**. Ein
gebauter, nie eingesteckter Sensor ist die reinste Form von *halb durchgesetzt*:
die Feedback-Hälfte existiert und wirkt trotzdem nicht.

Ziel der Welle ist deshalb **eine Antwort je Regel**, nicht ein Gate mehr:
entweder ein benannter Gate-Lauf, der sie trägt — oder die ausdrückliche
Ausweisung, dass sie einseitig bleibt.

## 2. Trigger (Welle startet)

- [welle-83](welle-83/welle-83-baseline-v5110-migration.md) ist geschlossen, ihre
  Ergebnisnotiz liegt in `done/`.
- `in-progress/` trägt keinen Slice.

## 3. Closure-Trigger (Welle schließt)

Regeln dieser Sektion: Baseline-Regelwerk `modul-06-roadmap.md`
§Wann Arbeit eine Welle braucht — der Trigger muss das *Mehr* gegenüber den
einzelnen Slice-DoDs benennen.

- **Der Zensus liegt vor:** je Hard Rule in [`AGENTS.md`](../../../../AGENTS.md) §3
  **und** der Botschafts-Regel in §5 eine Antwort **mit Beleg** — der tragende
  Gate-Lauf ist benannt, oder die Regel ist als **einseitig ausgewiesen**.
  **Keine Regel ohne Zeile.** Das ist das *Mehr*: eine Aussage über eine ganze
  Datei, die keine einzelne Slice-DoD belegen kann.
- **Was der Zensus als baubar ausweist, ist entweder in dieser Welle gebaut oder
  als Folge-Welle benannt** — nicht stillschweigend offen.
- `make fullbuild` grün (Exit explizit).
- Ergebnisnotiz `welle-84-results.md` mit Register-Lese-Schritt.

## 4. Slices in dieser Welle

| Slice | Rolle |
|---|---|
| [slice-132](slice-132-hard-rule-zensus.md) | **Der Zensus:** je Hard Rule eine Antwort mit Beleg; weist die einseitigen aus und **schneidet** den Rest |
| [slice-133](slice-133-baseline-sensor-verdrahten.md) | **Den verwaisten Sensor anschließen:** `--verify` als Gate, `--check-latest` als Target plus Nachtlauf |
| [slice-134](slice-134-nolintlint.md) | **Vom Zensus geschnitten:** `nolintlint` ins Lint-Profil — §3.2 ist die einzige Regel, deren verbotene Form heute nachweislich **wirkt** |
| [slice-135](slice-135-uses-pin-sensor.md) | **Vom Zensus geschnitten:** ein Sensor auf `uses:`-Pins — löst den Auflösungs-Trigger von §3.9 ein |
| [slice-136](slice-136-agents-34-klaerung.md) | **Berichtigung einer Zensus-Zeile:** §3.4 gegen den Kanon halten — Doppelung, Verschärfung oder keins von beidem, und die Ausweisung entsprechend richtigstellen |

slice-133 hing **nicht** am Zensus — er behob einen bereits belegten Fund.
slice-134 und slice-135 sind sein Ergebnis: von zehn geprüften Regeln sind
**zwei** einseitig **und baubar**, und beide werden in dieser Welle gebaut statt
als Folge-Welle vertagt. Die übrigen einseitigen sind im Regeltext als solche
ausgewiesen — ihre Durchsetzung wäre ein Heuristik-Wächter, und den schließt §6
aus.

**slice-136 kam nach dem Zensus dazu, auf Auftraggeber-Nachfrage.** Er baut
nichts, sondern berichtigt **eine Zeile** des Zensus: §3.4s ungedeckte Hälfte
trägt die Ausweisung *permanent*, also die Behauptung einer Unmöglichkeit — und
die war nicht geprüft. Die Closure-Bedingung dieser Welle verlangt je Regel eine
Antwort **mit Beleg**; eine unbelegte zählt nicht.

## 5. Abhängigkeiten

- **Blockiert:** eine mögliche **Produkt-Welle** (Freshness als Modul). Ihr
  Zuschnitt kommt aus dem Zensus und wird hier nicht vorweggenommen — die
  entscheidende Messung liegt vor: d-check scannt **nur Markdown** (467 geprüfte
  Dateien = 467 `.md`-Dateien), und die zwei ungewachten Toolchain-Pins stehen
  im `Dockerfile`, also außerhalb der gescannten Menge.
- **Wird blockiert von:** nichts.

## 6. Out-of-Scope für diese Welle

- **Kein Lastenheft-Delta und keine neuen `DC-FA-*`.** Ein Produkt-Delta hätte
  eine eigene Closure-Bedingung — ein Release —, und die gehört nicht in eine
  Durchsetzungs-Welle.
- **Kein Release.**
- **Keine Heuristik-Wächter.** Wo kein baubares Gate existiert, wird die
  Einseitigkeit **ausgewiesen**, nicht mit einem Wortlisten-Lint übertüncht. Der
  Kurs hat genau diese Forderung an unserem eigenen Konsumenten-CR abgelehnt:
  *ohne Baubarkeit wäre sie ein behauptetes Gate.*
- **Der übrige §5.** Der Zensus nimmt aus *Dokumentations-Regeln* **nur** die
  Botschafts-Regel — sie ist dort als Hard Rule mit Auflösungs-Trigger
  geschrieben, die übrigen Zeilen sind Konventionen, und `modul-09`s
  Zwei-Quadranten-Satz gilt der **Hard Rule**. Das ist eine gesetzte Grenze,
  keine Auslassung: ein eigener Zensus über §5 ist damit **benannt**, nicht
  vergessen.
- **Kein Mutations-Sensor.** Die Einführungs-Hälfte (*„Bewusstes Brechen"*)
  steht bereits gerankt in
  [`modul-13-quality-gates.md`](../../../../.harness/baseline/v5.11.0/regelwerk/modul-13-quality-gates.md#adr-zur-fitness-function);
  die **Haltbarkeits**-Frage wartet auf einen belegten Vorfall — das
  [Beobachtungs-Register](../observations.md) führt dazu **null von zwölf**
  Einträgen, und `modul-13` §Guard-Härtung verlangt Beobachtung statt
  Bedrohungsmodell.
